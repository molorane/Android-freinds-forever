package com.example.friendsforever;

public class FriendData {

    public String fNames;
    public String fPhoneNo;
    public String street;
    public String city;
    public String latitude;
    public String longitude;

    public FriendData(String fNames,String fPhone,String street,String city,String latitude,String longitude){
        this.fNames = fNames;
        this.fPhoneNo = fPhone;
        this.street = street;
        this.city = city;
        this.latitude = latitude;
        this.longitude = longitude;
    }
}
