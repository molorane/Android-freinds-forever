package com.example.friendsforever;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import static android.app.Activity.RESULT_OK;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentButtons extends Fragment {

    private Button btnSendSMS;
    private Button btnSendEmail;
    private Communicator comm;

    public FragmentButtons() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_buttons, container, false);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) { // if return coordinates was clicked from another activity
            if(resultCode == RESULT_OK) {
                sendAnotherSMS();
            }
        }else if (requestCode == 2) { // if return coordinates was clicked from another activity
            if(resultCode == RESULT_OK) {
                sendAnotherEmail();
            }
        }
    }


    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        btnSendSMS = getActivity().findViewById(R.id.btnSendSMS);
        btnSendEmail = getActivity().findViewById(R.id.btnSendEmail);

        btnSendSMS.setOnClickListener(btnSendSMSIListener);
        btnSendEmail.setOnClickListener(btnSendEmailIListener);

        comm = (Communicator) getActivity();
    }

    private Button.OnClickListener btnSendSMSIListener = new Button.OnClickListener(){
        @Override
        public void onClick(View v){

            if(!comm.getPhone().equals("")){
                String strPhoneNumber = comm.getPhone();
                String strSmsBody = smsMessage(comm.getFriendData());

                Uri uri = Uri.parse("smsto:" + strPhoneNumber);
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO, uri);
                smsIntent.putExtra("sms_body", strSmsBody);
                startActivityForResult(smsIntent, 1); // this will enable the control to be send back when the sms program is finished.
                sendAnotherSMS();
            }else{
                displayDialog("Cell number invalid!","Please enter a valid cell phone number before sending SMS.");
            }

        }
    };

    private Button.OnClickListener btnSendEmailIListener = new Button.OnClickListener(){
        @Override
        public void onClick(View v){

            if(!comm.getEmail().equals("")){
                String strEmail = comm.getEmail();
                String strSubject = comm.getSubject();
                String strSmsBody = smsMessage(comm.getFriendData());

                String[] toAddressStringArray = {strEmail};

                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.putExtra(Intent.EXTRA_EMAIL, toAddressStringArray);
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, strSubject);
                emailIntent.putExtra(Intent.EXTRA_TEXT, strSmsBody);
                emailIntent.setType("text/plain");
                Intent chooserIntent = Intent.createChooser(emailIntent, "Select a program from the list below");
                startActivityForResult(chooserIntent, 2); // this will enable the control to be send back when the email program is finished.
                sendAnotherEmail();
            }else{
                displayDialog("Missing information!","Please enter a valid email and/or subject before sending the email.");
            }
        }
    };


    public String smsMessage(FriendData data){

        String message = "Please verify your information:\n"+
                data.fNames+"\n"+
                "Phone no: "+data.fPhoneNo+"\n"+
                "Street: "+data.street+"\n"+
                "City: "+data.city+"\n"+
                "Latitude: "+data.latitude+"\n"+
                "Longitude: "+data.longitude;

        return message;
    }

    public void displayDialog(String title,String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("OK", null);
        AlertDialog errorDialog = builder.create();
        errorDialog.show();
    }


    public void sendAnotherSMS(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        builder.setTitle("Send another SMS?");
        builder.setMessage("Do you want to send another message?");

        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                // Do nothing but close the dialog

                if(!comm.getPhone().equals("")){
                    String strPhoneNumber = comm.getPhone();
                    String strSmsBody = smsMessage(comm.getFriendData());

                    Uri uri = Uri.parse("smsto:" + strPhoneNumber);
                    Intent smsIntent = new Intent(Intent.ACTION_SENDTO, uri);
                    smsIntent.putExtra("sms_body", strSmsBody);
                    startActivityForResult(smsIntent, 1);
                }else{
                    displayDialog("Cell number invalid!","Please enter a valid cell phone number before sending SMS.");
                }

                dialog.dismiss();
            }
        });

        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }


    public void sendAnotherEmail(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        builder.setTitle("Send another email?");
        builder.setMessage("Do you want to send another email?");

        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {
                // Do nothing but close the dialog

                if(!comm.getEmail().equals("")){
                    String strEmail = comm.getEmail();
                    String strSubject = comm.getSubject();
                    String strSmsBody = smsMessage(comm.getFriendData());

                    String[] toAddressStringArray = {strEmail};

                    Intent emailIntent = new Intent(Intent.ACTION_SEND);
                    emailIntent.putExtra(Intent.EXTRA_EMAIL, toAddressStringArray);
                    emailIntent.putExtra(Intent.EXTRA_SUBJECT, strSubject);
                    emailIntent.putExtra(Intent.EXTRA_TEXT, strSmsBody);
                    emailIntent.setType("text/plain");
                    Intent chooserIntent = Intent.createChooser(emailIntent, "Select a program from the list below");
                    startActivityForResult(chooserIntent, 2);
                }else{
                    displayDialog("Missing information!","Please enter a valid email and/or subject before sending the email.");
                }

                dialog.dismiss();
            }
        });

        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog alert = builder.create();
        alert.show();
    }

}
