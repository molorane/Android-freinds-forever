package com.example.friendsforever;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.text.NumberFormat;

public class current_location extends Activity  implements OnMapReadyCallback {

    private GoogleMap map = null;
    private LocationManager locManager = null;
    private LatLng currentPositionLatLng = null;

    private TextView latitudeTextView;
    private TextView longitudeTextView;

    private Button btnReturnCoordinates;
    private Button btnBack;

    private double latitude;
    private double longitude;
    private String friendNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.current_location);


        SeekBar customTipSeekBar = findViewById(R.id.skbZoom);
        customTipSeekBar.setOnSeekBarChangeListener(customSeekBarListener);

        latitudeTextView = findViewById(R.id.lblLatitude);
        longitudeTextView = findViewById(R.id.lblLongitude);

        btnReturnCoordinates = findViewById(R.id.btnReturnCoordinates);
        btnBack = findViewById(R.id.btnBack);

        btnReturnCoordinates.setOnClickListener(btnReturnCoordinatesIListener);
        btnBack.setOnClickListener(btnBackIListener);

        locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        FragmentManager manager = getFragmentManager();
        MapFragment mapDisplayFragment = (MapFragment) manager.findFragmentById(R.id.mapFragment);
        mapDisplayFragment.getMapAsync(this);

        String action = getIntent().getStringExtra("action");

        if(action.equals("getCoordinates")){
            btnBack.setEnabled(false);
            btnReturnCoordinates.setEnabled(true);
        }else{
            btnBack.setEnabled(true);
            btnReturnCoordinates.setEnabled(false);

            latitude = Double.parseDouble(getIntent().getStringExtra("latitude"));
            longitude = Double.parseDouble(getIntent().getStringExtra("longitude"));
            friendNames = getIntent().getStringExtra("fName");
        }
    }

    public void displayMapWithData(String fName,double latitude,double longitude){


        try{

            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    Activity#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for Activity#requestPermissions for more details.
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {

                map.clear();

                currentPositionLatLng = new LatLng(latitude, longitude);
                latitudeTextView.setText(latitude+"");
                longitudeTextView.setText(longitude+"");

                MarkerOptions options = new MarkerOptions();
                options.title("Location: "+fName);
                options.position(currentPositionLatLng);
                map.addMarker(options);

                //CameraUpdate update = CameraUpdateFactory.newLatLng(markerLatLng);
                CameraUpdate update = CameraUpdateFactory.newLatLngZoom(currentPositionLatLng, 10); //Zoom level between 2 van 21
                map.animateCamera(update);
            }
        }catch(Exception e){
            displayDialog("Error",e.getMessage());
        }


    }

    private Button.OnClickListener btnReturnCoordinatesIListener = new Button.OnClickListener(){
        @Override
        public void onClick(View v){

            String latitude = latitudeTextView.getText().toString();
            String longitude = longitudeTextView.getText().toString();

            Intent intent = new Intent();
            intent.putExtra("latitude", latitude);
            intent.putExtra("longitude", longitude);
            setResult(RESULT_OK, intent);
            finish();
        }
    };

    private Button.OnClickListener btnBackIListener = new Button.OnClickListener(){
        @Override
        public void onClick(View v){
            Intent intent = new Intent();
            setResult(RESULT_OK, intent);
            finish();
        }
    };

    private SeekBar.OnSeekBarChangeListener customSeekBarListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            updateZoom(progress);
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };

    private void updateZoom(int zoom){
        map.animateCamera( CameraUpdateFactory.zoomTo( zoom ) );
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        map = googleMap;

        map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        map.getUiSettings().setCompassEnabled(true);
        map.getUiSettings().setMapToolbarEnabled(true);
        map.getUiSettings().setAllGesturesEnabled(true);
        map.getUiSettings().setZoomControlsEnabled(true);
        map.getUiSettings().setRotateGesturesEnabled(true);
        map.getUiSettings().setScrollGesturesEnabled(true);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            map.setMyLocationEnabled(true);
            map.getUiSettings().setMyLocationButtonEnabled(true);

            displayMapWithData(friendNames,latitude,longitude);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

                        map.setMyLocationEnabled(true);
                        map.getUiSettings().setMyLocationButtonEnabled(true);
                        locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, locListener);
                    }
                }
                else{
                    Toast.makeText(current_location.this, "If you deny access to your location, this application will not function correctly", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    private LocationListener locListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {

            if (locManager != null){
                currentPositionLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                latitudeTextView.setText(Double.toString(location.getLatitude()));
                longitudeTextView.setText(Double.toString(location.getLongitude()));

                map.clear();
                MarkerOptions options = new MarkerOptions();
                options.title("Current Location");
                options.position(currentPositionLatLng);
                map.addMarker(options);

                //CameraUpdate update = CameraUpdateFactory.newLatLng(currentPositionLatLng);
                CameraUpdate update = CameraUpdateFactory.newLatLngZoom(currentPositionLatLng, 10); //Zoom levels can be between 2 and 21
                map.animateCamera(update);
            }
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    };


    public void displayDialog(String title,String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(current_location.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("OK", null);
        AlertDialog errorDialog = builder.create();
        errorDialog.show();
    }
}
