package com.example.friendsforever;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataSqlOpenHelper extends SQLiteOpenHelper {

    private  String strCreateDatabase = "CREATE TABLE contact_details (_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                                                                        "contact VARCHAR(100)," +
                                                                        "street VARCHAR(200)," +
                                                                        "city VARCHAR(100)," +
                                                                        "latitude VARCHAR(50)," +
                                                                        "longitude VARCHAR(50))";

    public DataSqlOpenHelper(Context context) {
        super(context, "friends.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(strCreateDatabase);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
