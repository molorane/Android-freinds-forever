package com.example.friendsforever;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentEmail extends Fragment {

    private EditText editTextEmail;
    private EditText editTextSubject;
    private EditText editTextMessageEmail;

    public FragmentEmail() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_email, container, false);
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        editTextEmail = getActivity().findViewById(R.id.editTextEmail);
        editTextSubject = getActivity().findViewById(R.id.editTextSubject);
        editTextMessageEmail = getActivity().findViewById(R.id.editTextMessageEmail);
    }


    public void fillEmailDetails(FriendData data){

        String message = "Please verify your information:\n"+
                data.fNames+"\n"+
                "Phone no: "+data.fPhoneNo+"\n"+
                "Street: "+data.street+"\n"+
                "City: "+data.city+"\n"+
                "Latitude: "+data.latitude+"\n"+
                "Longitude: "+data.longitude;

        editTextSubject.setText("Verify info: "+data.fNames);
        editTextMessageEmail.setText(message);
    }

    public String getEmail(){
        return editTextEmail.getText().toString();
    }

    public String getSubject(){
        return editTextSubject.getText().toString();
    }

}
