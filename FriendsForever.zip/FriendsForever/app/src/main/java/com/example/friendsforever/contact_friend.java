package com.example.friendsforever;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;

public class contact_friend extends Activity implements Communicator{

    Communicator comm;

    private String fNames;
    private String fPhoneNo;
    private String street;
    private String city;
    private String latitude;
    private String longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_friend);

        fNames = getIntent().getStringExtra("fNames");
        fPhoneNo = getIntent().getStringExtra("fPhoneNo");
        street = getIntent().getStringExtra("street");
        city = getIntent().getStringExtra("city");
        longitude = getIntent().getStringExtra("longitude");
        latitude = getIntent().getStringExtra("latitude");
    }

    @Override
    protected void onResume() {
        super.onResume();
        fillSMSDetails();
        fillEmailDetails();
    }

    @Override
    public void fillSMSDetails() {
        FragmentManager manager = getFragmentManager();
        FragmentSMS fragLeft = (FragmentSMS) manager.findFragmentById(R.id.fragment_sms);
        FriendData fdata = new FriendData(fNames,fPhoneNo,street,city,latitude,longitude);
        fragLeft.fillSMSDetails(fdata);
    }

    @Override
    public void fillEmailDetails() {
        FragmentManager manager = getFragmentManager();
        FragmentEmail fragRight = (FragmentEmail) manager.findFragmentById(R.id.fragment_email);
        FriendData fdata = new FriendData(fNames,fPhoneNo,street,city,latitude,longitude);
        fragRight.fillEmailDetails(fdata);
    }

    @Override
    public FriendData getFriendData() {
        FriendData fdata = new FriendData(fNames,fPhoneNo,street,city,latitude,longitude);
        return fdata;
    }

    @Override
    public String getPhone() {
        FragmentManager manager = getFragmentManager();
        FragmentSMS fragLeft = (FragmentSMS) manager.findFragmentById(R.id.fragment_sms);
        return fragLeft.getPhone();
    }

    @Override
    public String getEmail() {
        FragmentManager manager = getFragmentManager();
        FragmentEmail fragRight = (FragmentEmail) manager.findFragmentById(R.id.fragment_email);
        return fragRight.getEmail();
    }

    @Override
    public String getSubject() {
        FragmentManager manager = getFragmentManager();
        FragmentEmail fragRight = (FragmentEmail) manager.findFragmentById(R.id.fragment_email);
        return fragRight.getSubject();
    }
}
