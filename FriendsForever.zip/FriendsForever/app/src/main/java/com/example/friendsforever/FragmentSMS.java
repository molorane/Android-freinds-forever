package com.example.friendsforever;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import static android.content.Context.MODE_PRIVATE;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentSMS extends Fragment {

    private EditText editTextCellNo;
    private EditText editTextMessage;

    public FragmentSMS() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_sms, container, false);
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        editTextCellNo = getActivity().findViewById(R.id.editTextCellNo);
        editTextMessage = getActivity().findViewById(R.id.editTextMessage);
    }


    public void fillSMSDetails(FriendData data){

        String message = "Please verify your information:\n"+
                            data.fNames+"\n"+
                            "Phone no: "+data.fPhoneNo+"\n"+
                            "Street: "+data.street+"\n"+
                            "City: "+data.city+"\n"+
                            "Latitude: "+data.latitude+"\n"+
                            "Longitude: "+data.longitude;
        editTextMessage.setText(message);
    }


    public String getPhone(){
        return editTextCellNo.getText().toString();
    }

}
