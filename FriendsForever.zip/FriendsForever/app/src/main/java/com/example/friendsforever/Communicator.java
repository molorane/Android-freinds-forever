package com.example.friendsforever;

public interface Communicator {
    public  abstract void fillSMSDetails();
    public  abstract void fillEmailDetails();
    public abstract FriendData getFriendData();
    public abstract String getPhone();
    public abstract String getEmail();
    public abstract String getSubject();
}
