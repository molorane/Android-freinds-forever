package com.example.friendsforever;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

public class MainActivity extends Activity implements OnMapReadyCallback {

    private SharedPreferences ffSharedPreferences;
    private final static String friendsforever = "friendsforever";

    // variables for left side
    private EditText editTextNames;
    private EditText editTextPhoneNumber;
    private ImageButton imgbtnSaveInfo;

    private ListView friendsListView;
    private ArrayAdapter<String> friendsArrayAdapter;
    private ArrayList<String> sfriends = new ArrayList<String>();

    private SharedPreferences friendsSharedPreferences;
    private final static String friends = "friends";

    // variables for right side
    private Button btnSaveInformation;
    private Button btnGetCoordinates;

    private EditText editTextLatitude;
    private EditText editTextLongitude;
    private EditText editTextStreet;
    private EditText editTextCity;

    private int currentFriendID;

    private GoogleMap map = null;
    private LocationManager locManager = null;
    private LatLng currentPositionLatLng = null;

    private final static String[] selectOptions = {"Edit","Delete","Display on map","Verify info","Take a photo"};

    private DataSqlOpenHelper sqlHelper;
    private SQLiteDatabase userDetailsDB;


    private String selectedFName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialize leftpart variables
        friendsListView = findViewById(R.id.lvFriends);
        friendsSharedPreferences = getSharedPreferences(friends, MODE_PRIVATE);

        editTextNames = findViewById(R.id.editTextNames);
        editTextPhoneNumber = findViewById(R.id.editTextPhoneNo);

        imgbtnSaveInfo = findViewById(R.id.imgBtnSaveInfo);
        imgbtnSaveInfo.setOnClickListener(imgBtnSaveInfoIListener);


        // initialize right part variables
        editTextLatitude = findViewById(R.id.editTextLatitude);
        editTextLongitude = findViewById(R.id.editTextLongitute);
        editTextStreet = findViewById(R.id.editTextStreet);
        editTextCity = findViewById(R.id.editTextCity);

        btnGetCoordinates = findViewById(R.id.btnGetCoordinates);
        btnGetCoordinates.setOnClickListener(btnGetCoordinatesIListener);

        btnSaveInformation = findViewById(R.id.btnSaveInfo);
        btnSaveInformation.setOnClickListener(btnSaveInformationIListener);


        // disable buttons
        disableButtons();

        //friendsSharedPreferences.edit().clear().commit();

        Map<String, ?> conundrumData = friendsSharedPreferences.getAll();
        for (Map.Entry<String, ?> entry: conundrumData.entrySet()) {
            sfriends.add(entry.getKey().toString());
        }

        //Sort list of names before populating listview
        Collections.sort(sfriends, String.CASE_INSENSITIVE_ORDER);

        friendsArrayAdapter = new ArrayAdapter<String>(MainActivity.this, R.layout.list_item, sfriends);
        friendsListView.setAdapter(friendsArrayAdapter);

        friendsListView.setOnItemClickListener(listOnItemClick);
        friendsListView.setOnItemLongClickListener(listOnItemLongClick);


        sqlHelper = new DataSqlOpenHelper(MainActivity.this);
        currentFriendID = -1;

        locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        FragmentManager manager = getFragmentManager();
        MapFragment mapDisplayFragment = (MapFragment) manager.findFragmentById(R.id.mapFragment);
        mapDisplayFragment.getMapAsync(this);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2) { // if return coordinates was clicked from another activity
            if(resultCode == RESULT_OK) {
                String strLatitude = data.getStringExtra("latitude");
                String strLongitude = data.getStringExtra("longitude");

                editTextLatitude.setText(strLatitude);
                editTextLongitude.setText(strLongitude);
            }
        }else if(requestCode == 3){ // if back button was clicked from another activity
            if(resultCode == RESULT_OK) {
                editTextLatitude.setText("");
                editTextLongitude.setText("");
                editTextNames.setText("");
                editTextPhoneNumber.setText("");
                editTextStreet.setText("");
                editTextCity.setText("");
                btnGetCoordinates.setEnabled(false);
                btnSaveInformation.setEnabled(false);
            }
        }else if (requestCode == 1){ // if a photo was taken
            switch (resultCode){
                case RESULT_OK:
                    Bitmap saveBitmap = (Bitmap) data.getExtras().get("data");

                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    saveBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes); // The image Bitmap from number 2 gets compressed as a jpeg for saving and gets stored into a ByteArrayOutputStream
                    //Create a new file that will be stored in the SD card with a name selectedFName.
                    File imageFile = new File(Environment.getExternalStorageDirectory() + File.separator + selectedFName +".jpg");
                    try {
                        imageFile.createNewFile();
                        FileOutputStream fileOutPut = new FileOutputStream(imageFile);
                        //Write the Bitmap to the file by writing the BiteArrayOutputStream to the file using a FileOutputStream.
                        fileOutPut.write(bytes.toByteArray());
                        fileOutPut.close();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    Toast.makeText(MainActivity.this, "The file was saved at: " +imageFile.getAbsolutePath(), Toast.LENGTH_LONG).show();
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(MainActivity.this, "The file was not saved", Toast.LENGTH_LONG).show();
                    break;
                default:
                    break;
            }
        }
    }

    private Button.OnClickListener imgBtnSaveInfoIListener = new Button.OnClickListener(){
        @Override
        public void onClick(View v){

            String friendName = editTextNames.getText().toString();
            String friendCellno = editTextPhoneNumber.getText().toString();

            if(!friendName.equals("")){

                if(!friendExist(friendName)) {
                    addFriend(friendName, friendCellno);
                }else{
                    displayDialog("Contact name already exists!","Contact name already exists.All the contact names should be unique.Please enter a new contact name.");
                }
            }else{
                displayDialog("Missing Information","Friend name field can't be empty!");
            }

        }
    };

    private Button.OnClickListener btnGetCoordinatesIListener = new Button.OnClickListener(){
        @Override
        public void onClick(View v){
            Intent openActivity2Intent = new Intent(MainActivity.this, current_location.class);
            openActivity2Intent.putExtra("action", "getCoordinates");
            startActivityForResult(openActivity2Intent, 2);
        }
    };

    private Button.OnClickListener btnSaveInformationIListener = new Button.OnClickListener(){
        @Override
        public void onClick(View v){

            try{

                SQLiteDatabase userDetailsDB = sqlHelper.getWritableDatabase();

                String street = editTextStreet.getText().toString();
                String city = editTextCity.getText().toString();
                String latitude = editTextLatitude.getText().toString();
                String longitude = editTextLongitude.getText().toString();
                String fPhoneNo = editTextPhoneNumber.getText().toString();


                if(IsAllFieldsFilled(street,city,latitude,longitude)){

                    if(currentFriendID != -1){

                        ContentValues values = new ContentValues();
                        values.put("contact", fPhoneNo);
                        values.put("street", street);
                        values.put("city", city);
                        values.put("latitude", latitude);
                        values.put("longitude", longitude);
                        long rowUpdated = userDetailsDB.update("contact_details", values, "_id=" + currentFriendID, null);
                        userDetailsDB.close();

                        if (rowUpdated != -1) {

                            editFriendPhone();
                            disableButtons();
                            enableFields();

                            Toast.makeText(MainActivity.this, "Information updated", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Something wrong", Toast.LENGTH_SHORT).show();
                        }

                    }else {

                        ContentValues values = new ContentValues();
                        values.put("contact", fPhoneNo);
                        values.put("street", street);
                        values.put("city", city);
                        values.put("latitude", latitude);
                        values.put("longitude", longitude);
                        long rowInserted = userDetailsDB.insert("contact_details", null, values);
                        userDetailsDB.close();

                        if (rowInserted != -1) {
                            disableButtons();
                            enableFields();
                            editFriendPhone();

                            Toast.makeText(MainActivity.this, "Information saved", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Something wrong", Toast.LENGTH_SHORT).show();
                        }
                    }
                }else{
                    displayDialog("Missing information!","Please enter relevant information in the Latitude, Longitude, Street and City textboxes before clicking on the \"SAVE INFORMATION\" button");
                }

            }catch (SQLException e){
                displayDialog("Error occured!",e.getMessage());
            }
        }
    };

    public boolean IsAllFieldsFilled(String street,String city, String latitude, String longitude){

        if((!street.equals("") && !street.equalsIgnoreCase("N/A")) &&
                (!city.equals("") && !city.equalsIgnoreCase("N/A")) &&
                (!latitude.equals("") && !latitude.equalsIgnoreCase("N/A")) &&
                (!longitude.equals("") && !longitude.equalsIgnoreCase("N/A")) ){
            return true;
        }

        return false;
    }

    public void editFriendPhone(){
        String fPhoneNo = editTextPhoneNumber.getText().toString();
        String fNames = editTextNames.getText().toString();
        SharedPreferences.Editor friendsEditor = friendsSharedPreferences.edit();
        friendsEditor.putString(fNames, fPhoneNo);
        friendsEditor.apply();
    }

    public void addFriend(String names, String cellno){

        SharedPreferences.Editor friendsEditor = friendsSharedPreferences.edit();
        friendsEditor.putString(names, cellno);
        friendsEditor.apply();

        // clear the list view
        sfriends.add(names);

        //Sort list of names before populating list view
        Collections.sort(sfriends, String.CASE_INSENSITIVE_ORDER);

        friendsArrayAdapter.notifyDataSetChanged();

        friendsArrayAdapter = new ArrayAdapter<String>(MainActivity.this, R.layout.list_item, sfriends);
        friendsListView.setAdapter(friendsArrayAdapter);

        editTextNames.setText("");
        editTextPhoneNumber.setText("");

        Toast.makeText(MainActivity.this, "New Friend added!", Toast.LENGTH_LONG).show();
    }

    public boolean friendExist(String friend){
        return (friendsSharedPreferences.getString(friend, null) == null) ? false : true;
    }

    private AdapterView.OnItemClickListener listOnItemClick = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            //comm.Transfer(((TextView)view).getText().toString());

            String fNames = ((TextView)view).getText().toString();
            String fPhoneNo = friendsSharedPreferences.getString(fNames, "");

            editTextNames.setText(fNames);
            editTextPhoneNumber.setText(fPhoneNo);

            setSelectedFriendClick();

        }
    };

    public void setSelectedFriendLongClick(){
        try {

            String fPhoneNo = editTextPhoneNumber.getText().toString();
            SQLiteDatabase userDetailsDB = sqlHelper.getWritableDatabase();
            String[] columns = {"_id","contact", "street", "city", "latitude", "longitude"};
            String[] selectionArgs = {fPhoneNo};

            Cursor cursor = userDetailsDB.query("contact_details", columns, "contact = ?", selectionArgs, null, null, null);

            if(cursor.moveToNext()){

                currentFriendID = cursor.getInt(cursor.getColumnIndex("_id"));
                editTextLatitude.setText(cursor.getString(cursor.getColumnIndex("latitude")));
                editTextLongitude.setText(cursor.getString(cursor.getColumnIndex("longitude")));
                editTextStreet.setText(cursor.getString(cursor.getColumnIndex("street")));
                editTextCity.setText(cursor.getString(cursor.getColumnIndex("city")));
            }
            else{
                editTextLatitude.setText("N/A");
                editTextLongitude.setText("N/A");
                editTextStreet.setText("N/A");
                editTextCity.setText("N/A");
            }
            userDetailsDB.close();

        }catch (Exception e){
            displayDialog("Error occured!",e.getMessage());
        }
    }

    private AdapterView.OnItemLongClickListener listOnItemLongClick = new AdapterView.OnItemLongClickListener() {
        @Override
        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

            //Toast.makeText(MainActivity.this, "You longclicked on: " + ((TextView)view).getText().toString() + " - " + Integer.toString(position), Toast.LENGTH_LONG).show();

            final String fNames = ((TextView)view).getText().toString();
            final String fPhoneNo = friendsSharedPreferences.getString(fNames, "");

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Select an action");
            builder.setItems(selectOptions, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    switch (which){
                        case 0: //Edit
                            editTextNames.setText(fNames);
                            editTextPhoneNumber.setText(fPhoneNo);
                            editTextNames.setEnabled(false);
                            imgbtnSaveInfo.setEnabled(false);

                            setSelectedFriendLongClick();
                            enableButtons();
                            break;
                        case 1: //Delete

                            // delete data from shared preferences
                            SharedPreferences.Editor editor = friendsSharedPreferences.edit();
                            editor.remove(fNames);
                            editor.commit();

                            // delete data from database
                            deleteContact(fPhoneNo);

                            // delete data from list view
                            sfriends.remove(fNames);
                            friendsArrayAdapter.notifyDataSetChanged();

                            Toast.makeText(MainActivity.this, "Friend deleted!", Toast.LENGTH_LONG).show();
                            break;
                        case 2: //Display on map

                            displayOnMap(fPhoneNo,fNames);
                            break;
                        case 3: //Verify info
                            verifyInfo(fNames,fPhoneNo);
                            break;
                        case 4: //Take a photo

                            takePhoto(fNames);
                            break;
                        default:
                            break;
                    }
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            builder.create().show();

            return true;
        }
    };

    public void deleteContact(String fPhoneNo){
        SQLiteDatabase userDetailsDB = sqlHelper.getWritableDatabase();
        userDetailsDB.delete("contact_details", "contact=" + fPhoneNo, null);
    }

    public void takePhoto(String fNames){
        selectedFName = fNames;
        if(PhoneHasCamera()){
            Intent savePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(savePhotoIntent, 1);
        }else{
            displayDialog("Error!","Sorry your phone doesn't have a camera! You cannot take a photo.");
        }
    }

    public void verifyInfo(String fNames,String fPhoneNo){

        try{
            SQLiteDatabase userDetailsDB = sqlHelper.getWritableDatabase();
            String[] columns = {"_id","contact", "street", "city", "latitude", "longitude"};
            String[] selectionArgs = {fPhoneNo};

            Cursor cursor = userDetailsDB.query("contact_details", columns, "contact = ?", selectionArgs, null, null, null);

            if(cursor.moveToNext()) {

                String street = cursor.getString(cursor.getColumnIndex("street"));
                String city = cursor.getString(cursor.getColumnIndex("city"));
                String latitude = cursor.getString(cursor.getColumnIndex("latitude"));
                String longitude = cursor.getString(cursor.getColumnIndex("longitude"));

                // send this data to new activity
                Intent openActivity2Intent = new Intent(MainActivity.this, contact_friend.class);
                openActivity2Intent.putExtra("fNames", fNames);
                openActivity2Intent.putExtra("fPhoneNo", fPhoneNo);
                openActivity2Intent.putExtra("street", street);
                openActivity2Intent.putExtra("city", city);
                openActivity2Intent.putExtra("latitude", latitude);
                openActivity2Intent.putExtra("longitude", longitude);
                startActivity(openActivity2Intent);

            }
        }catch (Exception e){

        }
    }

    private boolean PhoneHasCamera(){
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }


    public void displayOnMap(String fPhoneNo,String fNames){
        SQLiteDatabase userDetailsDB = sqlHelper.getWritableDatabase();
        String[] columns = {"_id","contact", "street", "city", "latitude", "longitude"};
        String[] selectionArgs = {fPhoneNo};
        Cursor cursor = userDetailsDB.query("contact_details", columns, "contact = ?", selectionArgs, null, null, null);

        if(cursor.moveToNext()) {

            Intent openActivity2Intent = new Intent(MainActivity.this, current_location.class);
            openActivity2Intent.putExtra("action", "displayMap");
            openActivity2Intent.putExtra("latitude", cursor.getString(cursor.getColumnIndex("latitude")));
            openActivity2Intent.putExtra("longitude", cursor.getString(cursor.getColumnIndex("longitude")));
            openActivity2Intent.putExtra("fName", fNames);
            startActivityForResult(openActivity2Intent, 3);

        }else{
            displayDialog("No GPS Coordinates available!","Please update the GPS coordinates (latitude and longitude) for this contact via \"Edit\" function before you can view the location on the map.");
        }
    }

    public void enableFields(){
        editTextNames.setText("");
        editTextPhoneNumber.setText("");
        editTextNames.setEnabled(true);
        imgbtnSaveInfo.setEnabled(true);
    }

    public void disableButtons(){
        btnGetCoordinates.setEnabled(false);
        btnSaveInformation.setEnabled(false);
    }

    public void enableButtons(){
        btnGetCoordinates.setEnabled(true);
        btnSaveInformation.setEnabled(true);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        map = googleMap;

        map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        map.getUiSettings().setCompassEnabled(true);
        map.getUiSettings().setMapToolbarEnabled(true);
        map.getUiSettings().setAllGesturesEnabled(true);
        map.getUiSettings().setZoomControlsEnabled(true);
        map.getUiSettings().setRotateGesturesEnabled(true);
        map.getUiSettings().setScrollGesturesEnabled(true);

        if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            map.setMyLocationEnabled(true);
            map.getUiSettings().setMyLocationButtonEnabled(true);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

                        map.setMyLocationEnabled(true);
                        map.getUiSettings().setMyLocationButtonEnabled(true);
                        locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, locListener);
                    }
                }
                else {
                    finish();
                    System.exit(0);
                }
            }
        }
    }

    private LocationListener locListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {

            if (locManager != null){
                currentPositionLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                editTextLatitude.setText(Double.toString(location.getLatitude()));
                editTextLongitude.setText(Double.toString(location.getLongitude()));

                map.clear();
                MarkerOptions options = new MarkerOptions();
                options.title("Location: " + location.getLatitude()+ " (Lat), " +location.getLongitude()+ " (Lng)");
                options.position(currentPositionLatLng);
                map.addMarker(options);

                //CameraUpdate update = CameraUpdateFactory.newLatLng(currentPositionLatLng);
                CameraUpdate update = CameraUpdateFactory.newLatLngZoom(currentPositionLatLng, 16); //Zoom levels can be between 2 and 21
                map.animateCamera(update);
            }
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    };

    public void displayDialog(String title,String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("OK", null);
        AlertDialog errorDialog = builder.create();
        errorDialog.show();
    }

    public void setSelectedFriendClick(){

        try {

            String fPhoneNo = editTextPhoneNumber.getText().toString();
            SQLiteDatabase userDetailsDB = sqlHelper.getWritableDatabase();
            String[] columns = {"_id","contact", "street", "city", "latitude", "longitude"};
            String[] selectionArgs = {fPhoneNo};

            Cursor cursor = userDetailsDB.query("contact_details", columns, "contact = ?", selectionArgs, null, null, null);

            if(cursor.moveToNext()){
                editTextLatitude.setText(cursor.getString(cursor.getColumnIndex("latitude")));
                editTextLongitude.setText(cursor.getString(cursor.getColumnIndex("longitude")));
                editTextStreet.setText(cursor.getString(cursor.getColumnIndex("street")));
                editTextCity.setText(cursor.getString(cursor.getColumnIndex("city")));
            }
            else{
                editTextLatitude.setText("N/A");
                editTextLongitude.setText("N/A");
                editTextStreet.setText("N/A");
                editTextCity.setText("N/A");
            }
            userDetailsDB.close();

        }catch (Exception e){
            displayDialog("Error occured!",e.getMessage());
        }
    }
}
